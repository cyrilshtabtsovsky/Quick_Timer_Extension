document.getElementById('start').addEventListener('click', () => {
    const minutes = parseInt(document.getElementById('minutes').value) || 0;
    const seconds = parseInt(document.getElementById('seconds').value) || 0;
    const totalSeconds = (minutes * 60) + seconds;
    startTimer(totalSeconds);
  });
  
  function startTimer(duration) {
    let timer = duration, minutes, seconds;
    const countdownElem = document.getElementById('countdown');
    const interval = setInterval(() => {
      minutes = parseInt(timer / 60, 10);
      seconds = parseInt(timer % 60, 10);
  
      minutes = minutes < 10 ? "0" + minutes : minutes;
      seconds = seconds < 10 ? "0" + seconds : seconds;
  
      countdownElem.textContent = minutes + ":" + seconds;
  
      if (--timer < 0) {
        clearInterval(interval);
        alert('Time is up!');
      }
    }, 1000);
  }  